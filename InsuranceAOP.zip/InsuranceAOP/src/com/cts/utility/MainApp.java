package com.cts.utility;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.business.Transaction;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         ApplicationContext ctx =new ClassPathXmlApplicationContext("spring-bean.xml");
         Transaction tran =(Transaction) ctx.getBean("transaction");
         System.out.println(tran.addTransaction(5675));
         System.out.println(tran.addTransaction(5675));
         System.out.println(tran.withdrawTransaction(1000));
	}

}
