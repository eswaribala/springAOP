package com.cts.aspects;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;



@Aspect
public class InsuranceAspect {
	private final static Logger logger = Logger.getLogger( InsuranceAspect .class.getName()); 
	
	   public  InsuranceAspect() throws SecurityException, IOException
	   {
		   FileHandler fh = new FileHandler("C:/temp/InsuranceLogFile.log");
			 logger.addHandler(fh);

	   }
	   @Before("execution(* com.cts.business.Transaction.*(..))")
		public void transactionLogBefore(JoinPoint joinPoint) {

			System.out.println("Add Transaction logBefore()  running!");
			 logger.log(Level.INFO, joinPoint.getSignature().getName());
			System.out.println(joinPoint.getSignature().getName());		
			for(Object obj :joinPoint.getArgs())
                          System.out.println("Value passed to the method"+obj.toString());			
			System.out.println("******");
		}
		
	   @Around("execution(* com.cts.business.Transaction.*(..))")
		public void transactionLogAroud(ProceedingJoinPoint joinPoint) {

			System.out.println("Add Transaction under Execution!");
			 logger.log(Level.INFO, joinPoint.getSignature().getName());
			System.out.println(joinPoint.getSignature().getName());		
			for(Object obj :joinPoint.getArgs())
                         System.out.println("Value passed to the method"+obj.toString());		
			           try {
						Object obj=   joinPoint.proceed();
						System.out.println("Value under process"+obj);
					} catch (Throwable e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			
			
			System.out.println("******");
		}
	   @AfterReturning(
			      pointcut = "execution(* com.cts.business.Transaction.*(..))",
			      returning= "result")
		public void transactionLogAfterReturning(JoinPoint joinPoint,Object result) {
			System.out.println("logAfterReturning() is running!");
			System.out.println("hijacked : " + joinPoint.getSignature().getName());
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     System.out.println("Value after return"+result); 	
			System.out.println("******");
		}
	   
		
}
