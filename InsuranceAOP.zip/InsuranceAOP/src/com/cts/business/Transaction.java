package com.cts.business;

import org.springframework.stereotype.Component;

@Component
public class Transaction {
 private int balance;
	public int addTransaction(int amount)
	{
		balance=balance+amount;
		return balance;
	}
	public int withdrawTransaction(int amount)
	{
		if(balance > amount)
		 balance=balance-amount;
		return balance;
	}
}
